# Enterprise AI Operating Model Template

## \## 1. Business Outcomes

## \## 2. AI Use Cases

## 3. Platform Decisions

-   Prebuilt / SaaS:
-   Copilot Studio:
-   Microsoft Foundry:
-   Custom model:

## 4. Roles

-   Executive Sponsor:
-   AI CoE Lead:
-   Product Owner:
-   Solution Architect:
-   Data Owner:
-   Security:
-   Compliance:
-   Operations:
-   Business SMEs:

## 5. Data and Knowledge

-   Authoritative sources:
-   Access model:
-   Retention:
-   Data residency / transfer:

## 6. Rules and Guardrails

-   Human approval:
-   Tool/action limits:
-   Prompt rules:
-   Evaluation:

## 7. AI CoE

-   Governance:
-   Standards:
-   Reusable assets:
-   Skills:
-   Portfolio management:

## 8. Adoption

-   User personas:
-   Training:
-   AI champions:
-   Measurement:

## 9. Operations

-   Monitoring:
-   Cost:
-   Incident management:
-   Change management:
-   Retirement:
