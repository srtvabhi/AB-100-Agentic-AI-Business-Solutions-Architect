# Contoso X200 Warranty Policy --- Approved

**Document status:** Approved\
**Policy owner:** Customer Support Operations\
**Effective:** 2026\
**Product:** Contoso X200

## Warranty Period

The Contoso X200 is covered for **24 months from the date of purchase**,
subject to the terms and exclusions in this policy.

## Support

Customer-service employees may explain the published warranty terms.

Employees must not: - invent coverage - approve exceptions unless
authorized - provide legal interpretations - change the effective period

## Escalation

If the policy does not answer a question, escalate to the authorized
support or legal process.

## Exclusions

Normal exclusions and eligibility conditions must be checked against the
approved policy before a coverage decision is made.
