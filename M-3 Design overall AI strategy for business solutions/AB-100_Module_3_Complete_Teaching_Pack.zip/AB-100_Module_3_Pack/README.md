# AB-100 Module 3 --- Complete Teaching Pack

## Contents

1.  `AB-100_Module_3_Participant_Guide.md`
    -   17 Learn-aligned topics
    -   Concept
    -   Architecture Perspective
    -   Whiteboard architecture
    -   Architect questions and expected answers
    -   Final module architecture
2.  `Case_Studies/`
    -   Enterprise AI Adoption Strategy
    -   Single Agent or Multi-Agent
    -   Extend Microsoft 365 Copilot or Build a Custom Agent
    -   AI Strategy for a Regulated Global Business
3.  `Hands_On_Labs/AB-100_Module_3_Hands-On_Lab_Guide.md`
    -   Lab 1: AI use-case and platform strategy
    -   Lab 2: Governed knowledge agent
    -   Lab 3: Prompt library and prompt engineering
    -   Lab 4: Enterprise AI operating model workshop
4.  `Lab_Artifacts/`
    -   AI use-case portfolio workbook
    -   Approved warranty policy
    -   Unsupported policy test document
    -   Prompt library CSV
    -   AI operating model template

## Platform Validation

-   Lab 1: Copilot in Excel + Microsoft 365 Copilot Chat
-   Lab 2: Microsoft Copilot Studio
-   Lab 3: Microsoft 365 Copilot Chat + Microsoft Copilot Studio
-   Lab 4: Architecture workshop with optional Dynamics 365 environment

Microsoft Learn currently documents Copilot Studio knowledge sources,
tools, connected agents, testing and publishing, and the Module 3
learning objectives explicitly cover CAF, agent operating model,
Microsoft platform selection, and PoC-to-production transition.

## Source

Primary source: Microsoft Learn --- Design overall AI strategy for
business solutions.
